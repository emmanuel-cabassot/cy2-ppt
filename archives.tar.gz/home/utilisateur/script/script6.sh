#!/bin/bash

grep '^Job' /home/utilisateur/document.txt 
