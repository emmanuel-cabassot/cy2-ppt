#!/bin/bash

grep -c 'e'  /home/utilisateur/document.txt
