#!/bin/bash

grep [0-9] /home/utilisateur/document.txt
