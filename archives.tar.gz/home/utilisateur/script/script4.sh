#!/bin/bash

grep 'ch' /home/utilisateur/document.txt | grep 'j' /home/utilisateur/document.txt
