#!/bin/bash


grep ^[jJ] /home/utilisateur/document.txt
