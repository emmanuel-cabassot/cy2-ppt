#!/bin/bash

grep ^[A-Z] /home/utilisateur/document.txt
